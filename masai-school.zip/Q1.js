console.log("masaischool");
console.log("A transformation in education");