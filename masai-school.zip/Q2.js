Name="Subrat kumar Nayak";
console.log("Subrat kumar Nayak");
Name1="Chhabila kishore Nayak";
console.log("Chhabila kishore Nayak");
Name2="Sanjukta Nayak";
console.log("Sanjukta Nayak");