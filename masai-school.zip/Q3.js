Name="subrat kumar nayak";
Age=23;
console.log("subrat kumar nayak"); console.log(23); 